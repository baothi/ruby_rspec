<?php
namespace App\Shell;

use Cake\Console\Shell;



class HelloShell extends AppShell {
    public function main() {
        $this->out('Hello world.');
    }
}
