<?php
$map = array();